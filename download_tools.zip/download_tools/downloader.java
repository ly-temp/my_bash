import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.lang.annotation.Target;
import java.lang.reflect.Array;
import java.net.URL;
import java.net.URLConnection;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;
import java.util.Scanner;



/**
public static String newline = System.getProperty("line.separator");
public static char sep = File.separatorChar;
*/



class downloader{
    static final int indicator_len = 2;
    static final String strg_file_sep = "\t";
    static final String indicator_sign = ";";
    static final String int_indicator = ";d";
    static final String strg_indicator = ";s";
    static final String count_indicator = ";c";
    static final String download_folder_name = "download";
    static final String temp_name = "temp.ly";
    static String temp_dir = "";
    static final String stop_name = "pause.ly";
    static String stop_dir = "";
    static String download_dir = "";
    static String strg_dir = "";

    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    public static void main(String args[]){
        Scanner in = new Scanner(System.in);


        char sep = File.separatorChar;
        String dir = "";

        Termainal_IO termainal_io = new Termainal_IO();
        System.out.println("Input file dir.");
        dir = termainal_io.get_dir();

        temp_dir = dir + temp_name;
        stop_dir = dir + stop_name;
        download_dir = dir + download_folder_name + sep;
        
        System.out.println("Separator is: " + sep);
        System.out.println("Dir is: " + dir);

        //create download dir if not exist
        try{
            File download_dir_file = new File(download_dir);
            if(!download_dir_file.isDirectory()){
                System.out.println("Download dir created: " + download_dir);
                download_dir_file.mkdir();
            }
        }catch(Exception e){
            System.out.println("Downloader class: main has error!");
            System.out.println(e);
        }


        File_IO file_io = new File_IO();
        Link_Function link_function = new Link_Function();
        
        try{
            File tp_file = new File(dir + temp_name);
            if(!tp_file.exists()){  //initialize tepm file if not exists
                System.out.print("Enter URL(use ; as replace sign): ");
                String temp_url = in.nextLine();

                file_io.write_f(temp_dir, temp_url + newline, 'a');      //template url
                int n_int = link_function.count_target(temp_url, int_indicator);
                int n_strg = link_function.count_target(temp_url, strg_indicator);
                for(int i = 0; i < n_int + n_strg; i++){
                    file_io.write_f(temp_dir, "0 ", 'a');        //initalize current index --> for int mode
                                                                    //for int: use as counter
                                                                    //for strg: use as pointer in source_list
                }
                file_io.write_f(temp_dir, newline, 'a');
                System.out.print("Enter no. of max value for int indicator: ");
                long max_int_indicator = termainal_io.in.nextLong();
                termainal_io.in.nextLine();

                Boolean is_numbering_download = termainal_io.get_bool("Use numbering download? (T/F)"); //all download file use number as file name


                file_io.write_f(temp_dir, Long.toString(max_int_indicator), 'a');
                file_io.write_f(temp_dir, newline + "0", 'a');  //downloader counter initalize
                file_io.write_f(temp_dir, newline + is_numbering_download.toString(), 'a');
            }
        }catch(Exception e){
            System.out.println("Doanloader class: main has error!");
            System.out.println(e);
        }

 
        if(termainal_io.get_bool("Import string txt file?(T/F): ")){
            File strg_file;
            boolean is_first = true;
            do{
                if(!is_first){
                    System.out.print("File not exists. Try again!");
                }
                is_first = false;
                System.out.print("Input string txt file name: ");
                strg_dir = dir + termainal_io.in.nextLine();
                strg_file = new File(strg_dir);
            }while(!strg_file.exists());
        }        

        termainal_io = null;


        //input template data
        String temp_url = ""; 
        String data_strg_temp = "";
        Long max_int_indicator = -1L;
        Long download_counter = -1L;    //for count indicator replacement
        Boolean is_numbering_download = false;

        try{
            File temp_file = new File(temp_dir);
            Scanner temp_file_in = new Scanner(temp_file);
            temp_url = temp_file_in.nextLine();
            data_strg_temp = temp_file_in.nextLine();
            max_int_indicator = Long.parseLong(temp_file_in.nextLine());
            download_counter = Long.parseLong(temp_file_in.nextLine());
            is_numbering_download = Boolean.parseBoolean(temp_file_in.nextLine());
        }catch(Exception e){
            System.out.println("Doanloader class: main has error!");
            System.out.println(e);
        }

        String data_strg_split[] = data_strg_temp.split(" ");
        long temp_data[] = new long[data_strg_split.length];
        for(int i = 0; i < data_strg_split.length; i++){
            temp_data[i] = Integer.parseInt(data_strg_split[i]);
        }

        int no_int_sep = link_function.count_target(temp_url, int_indicator);
        int no_strg_sep = link_function.count_target(temp_url, strg_indicator);
        int no_count_sep = link_function.count_target(temp_url, count_indicator);
        final int no_total_sep = no_int_sep + no_strg_sep;  //exclude counter indicator
        int int_pt[] = new int[no_int_sep];
        int strg_pt[] = new int[no_strg_sep];
        for(int n = 0, pos = 0; n < no_total_sep; ){
            int int_pt_count = 0;
            int strg_pt_count = 0;
            pos = temp_url.indexOf(indicator_sign, pos);
            String sub_strg = temp_url.substring(pos, pos + indicator_len);
            switch(sub_strg){
                case int_indicator:
                    int_pt[int_pt_count] = n;
                    int_pt_count++;
                    n++;
                    pos++;
                    break;
                case strg_indicator:
                    strg_pt[strg_pt_count] = n;
                    strg_pt_count++;
                    n++;
                    pos++;
                    break;
            }
        }


        System.out.println("Start doanload process.");
        //end of testing
        System.out.println("Create file \"" + stop_name + "\" at \"" + dir + "\" to pause the download (i.e.\"" + dir + stop_name + "\")");
        //start download
        File stop_file = new File(stop_dir);
        String temp_url_back = temp_url;
        while(!stop_file.exists()){
            //counter store in 'temp_data[]' corresponding to their order in template url 'temp_url'
            temp_url = temp_url_back;
            int pos = 0;
            int strg_count = 0;
            int count_count = 0;
            ////int int_count = 0;
            ////int int_pt[] = new int[no_int_sep];
            ////int strg_pt[] = new int[no_strg_sep];
            //replace indicator with content
            for(int i = 0; i + count_count < temp_data.length + no_count_sep; ){
                ////long data_i  = temp_data[i];
                long data_i = -1L;
                if(i < temp_data.length){
                    data_i = temp_data[i];
                }
                Boolean has_replace = true;
                do{
                    has_replace = true;
                    pos = temp_url.indexOf(indicator_sign, pos);
                    String sub_strg = temp_url.substring(pos, pos + indicator_len);
                    switch(sub_strg){
                        case int_indicator:
                            temp_url = temp_url.replaceFirst(int_indicator, Long.toString(data_i));
                            pos = pos + Long.toString(data_i).length();//lenof(int)
                            ////int_pt[int_count] = i;
                            ////int_count++;
                            i++;
                            break;
                        case strg_indicator:
                            //replace with string list
                            //program not done yet
                            {
                                String split_temp_strg[] = file_io.read_file(strg_dir, data_i + 1).split(strg_file_sep);
                                temp_url = temp_url.replaceFirst(strg_indicator, split_temp_strg[strg_count]);
                                pos = pos + split_temp_strg[strg_count].length();
                                ////strg_pt[strg_count] = i;
                                strg_count++;
                                i++;
                                break;
                            }
                        case count_indicator:
                            temp_url = temp_url.replaceFirst(count_indicator, Long.toString(download_counter));
                            pos = pos + Long.toString(download_counter).length();
                            count_count++;
                            break;
                        default:
                            pos++;
                            has_replace = false;
                            break;
                    }
                }while(!has_replace);
            }


            //download
            try{
                File download_f;
                String filename = "";
                if(temp_url.indexOf("/") == temp_url.length()-1){
                    //remove terminal '/'
                    temp_url = temp_url.substring(0, temp_url.length()-1);
                }
                int dot_pos = temp_url.indexOf(".", temp_url.lastIndexOf("/") + 1);


                System.out.print("Downloading: " + temp_url);
                URL down_url = new URL(temp_url);
                ReadableByteChannel rbc = Channels.newChannel(down_url.openStream());
                FileOutputStream fos;


                if(is_numbering_download){
                    filename = download_counter.toString();
                }else{
                    if(dot_pos != -1){
                        filename = temp_url.substring(temp_url.lastIndexOf("/") + 1);
                    }else{
                        //no suffix in url
                        filename = download_counter.toString();
                    }
                }

                download_f = new File(download_dir + filename);
                if(download_f.exists()){
                    //overlap with exist file name
                    //HELP: find better file name, e.g. xx(1) xx(2)
                    int duplicate_counter = 1;
                    do{
                        String new_filename = filename + "_" + duplicate_counter;    //duplicate file format --> modiftable
                        download_f = new File(download_dir + new_filename);
                        duplicate_counter++;
                    }while(download_f.exists());
                }

                
                download_f.createNewFile();

                fos = new FileOutputStream(download_f);   //help: determine suffix
                //fos = new FileOutputStream(download_f + download_counter);   //help: determine suffix


                Thread.sleep(1000);//prevent 522 server timeout

                fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
                fos.close();

                System.out.println(" [Success]");
                download_counter++;
            }catch(Exception e){
                // System.out.println("Downloader Class: main has error!");
                System.out.println(" [Error]");
                System.out.println("    " + e);      //for debug
            }

            //check for end
//            if(no_strg_sep == 0 && temp_data[int_pt[int_pt.length-1]] > max_int_indicator){
  //              break;
    //        }
            if(no_int_sep > 0){
                temp_data[int_pt[0]]++;
            }
            //inc int counter
            for(int i = 0; i < int_pt.length - 1; i++){
                if(temp_data[int_pt[i]] > max_int_indicator){
                    temp_data[int_pt[i]] = 0;
                    temp_data[int_pt[i+1]]++;
                }
            }

            if(no_int_sep > 0){
                if(temp_data[int_pt[int_pt.length-1]] > max_int_indicator){
                    //inc all string counter in file when all integer counter has reach max
                    if(no_strg_sep > 0 && no_int_sep > 0){
                        for(int pt : strg_pt){
                            temp_data[pt]++;
                        }
                        for(int pt : int_pt){
                            temp_data[pt] = 0;
                        }
                    }else{
                        //not string --> finish all download
                        break;
                    }
                }
            }else{
                for(int pt : strg_pt){
                    temp_data[pt]++;
                }
            }
            

            //check for end
            if(no_strg_sep > 0){
                if(file_io.read_file(strg_dir, temp_data[strg_pt[0]] + 1).equals(file_io.eof_sign)){
                    break; 
                }
            }

            //update to temp file
            String out_data = "";
            boolean is_first = true;
            for(long data : temp_data){
                if(is_first){
                    out_data = out_data + Long.toString(data);
                    is_first = false;
                }else{
                    out_data = out_data + " " + Long.toString(data);
                }
                file_io.change_f_line(temp_dir, out_data, 2);
            }
            file_io.change_f_line(temp_dir, Long.toString(download_counter), 4);


            
        }

    }

}

class Link_Function{

    String replace_all_with(String strg, String replace_this, String with_this){
        String output = "";
        int i = 0;
        int copy_start = 0;
        while(i <= strg.length() - replace_this.length()){

            int j = 0;
            boolean match = true;
            while(j < replace_this.length() && match){
                match = (strg.charAt(i+j) == replace_this.charAt(j));
                j++;
            }
            if(match){
                String temp_strg = "";
                int a = copy_start;
                while(a < i){
                    temp_strg = temp_strg + strg.charAt(a);
                    a++;
                }
                temp_strg = temp_strg + with_this;
                output = output + temp_strg;
                copy_start = i + replace_this.length();
            }
            i = i + j;
        }
        return output;
    }

    //find number of targets inside input content
    int count_target(String content, String target){
        int n = 0;
        int i = 0;
        while(i <= content.length() - target.length()){
            boolean match = true;
            int j = 0;
            while(j < target.length() && match){
                match = (content.charAt(i + j) == target.charAt(j));
                j++;
            }
            if(match){
                n++;
            }
            i = i + j;
        }
        return n;
    }
}

class Termainal_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    Scanner in = new Scanner(System.in);

    boolean get_bool(String description){
        boolean output = false;
        boolean valid = false;
        do{
            System.out.print(description);
            String input = in.nextLine();
            switch(input){
                case "t":
                case "T":
                case "1":
                case "True":
                case "TRUE":
                case "true":
                    output = true;
                    valid = true;
                    break;
                case "f":
                case "F":
                case "0":
                case "False":
                case "FALSE":
                case "false":
                    output = false;
                    valid = true;
                    break;

            }
        }while(!valid);
        return output;
    }

    //the return dir may or may not has 'sep'
    String get_dir(){
        File file;
        String dir = "";
        boolean is_first = true;
        do{
            if(!is_first){
                System.out.println("Invalid dir. Try again!");
                print_line_sep();
            }
            is_first = false;
            System.out.print("Enter dir: ");
            dir = in.nextLine();
            //add 'sep' if missing
            if(dir.charAt(dir.length()-1) != sep){
                dir = dir + sep;
            }
            file = new File(dir);
        }while(!file.isDirectory());
        return dir;
    }
    
    void print_line_sep(){
        System.out.println("--------------------------------------");
    }
}

class File_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    public static String eof_sign = "\n!!!EOF!!!";

    String read_file(String path, long line){    //line begin at 1
        String content = "";
        try{
            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            long i = 0;
            do{
                content = fr.nextLine();
                i++;
            }while(i < line && fr.hasNextLine());
            fr.close();
            if(i < line){
                content = eof_sign;
            }
        }catch(Exception e){
            System.out.println("File_IO Class: read_file has error!");
            System.out.println(e);
        }
        return content;
    }

    void change_f_line(String path, String content, int line){
        try{
            ArrayList<String> file_content = new ArrayList<String>();

            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            for(int i = 1; fr.hasNextLine(); i++){  //i: current line
                if(i == line){
                    //replace the line
                    fr.nextLine();
                    file_content.add(content);
                }else{
                    file_content.add(fr.nextLine());
                }
            }
            fr.close();
            FileWriter fw = new FileWriter(file, false);
            for(int i = 0; i < file_content.size(); i++){
                fw.write(file_content.get(i));
                if(i != file_content.size() - 1){
                    fw.write(newline);
                }
            }
            fw.close();
        }catch(Exception e){
            System.out.println("File_IO Class: change_f_line has error!");
            System.out.println(e);
        }
    }
    
    void write_f(String path, String content, char mode){
        File file = new File(path);

        if(file.exists()){
            boolean perserve_content = true;
            switch(mode){
                case 'a':   //append mode
                case 'A':
                        perserve_content = true;
                        break;
                case 'o':   //overwrite mode
                case 'O':
                        perserve_content = false;
                        break;
            }
            try{
                FileWriter fw = new FileWriter(file, perserve_content);
                fw.write(content);
                fw.close();
                System.out.println("written to file: " + path);
            }catch(Exception e){
                System.out.println("File_IO Class: write_f has error!");
                System.out.println(e);
            }
        }else{
            try{
                file.createNewFile();
                FileWriter fw = new FileWriter(file);
                fw.write(content);
                fw.close();
                System.out.println("File created: " + path);
            }catch(Exception e){
                System.out.println("File_IO Class: write_f() has error!");
                System.out.println(e);
            }
        }
    }
}