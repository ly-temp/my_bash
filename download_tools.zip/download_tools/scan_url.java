import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.nio.Buffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;

class scan_url{
    final static String url_sep = "/";
    final static String url_file = "url.ly";
    final static String temp_file = "temp_url.ly";
    final static String setting_file = "setting_url.ly";
    // final static String temp_html_file = "temp_html.ly";
    final static String pause_file = "pause.ly";
    final static String newline = System.getProperty("line.separator");
    final static String skip_suffixs[] = {"png", "jpeg" , "jpg", "mp4", "mp3", "webp", "wmv", "pdf"};
    final static String protocols[] = {"http://", "https://", "ftp://"};
    final static String default_protcol = protocols[0];
    final static String ref_tag = "href=";
    final static String tags[] = {ref_tag ,"onclick=","src="};
    //custom code
    final static String replace_list[] = {"&amp;"};
    final static String with_list[] = {"&"};
    //end of custom code


    public static void main(String args[]){
        
        Termainal_IO terminal_io = new Termainal_IO();
        File_IO file_io = new File_IO();
        // Link_Function link_function = new Link_Function();

        System.out.println("Enter temp dir.");
        String dir = terminal_io.get_dir();
        final String url_dir = dir + url_file;
        final String temp_dir = dir + temp_file;
        final String pause_dir = dir + pause_file;
        final String setting_dir = dir + setting_file;
        boolean is_same_site = true;
        boolean inc_media = false;
        boolean is_broad_mode = false;
        String home_domain = "";
        String true_home_domain = "";
        // final String temp_html_dir = dir + temp_html_file;

        try{
            File url_f = new File(url_dir);
            if(!url_f.exists()){
                // url_f.createNewFile();
                // System.out.println("Created url file");
                //input initial url
                System.out.print("Enter initial URL: ");
                home_domain = terminal_io.in.nextLine();
                file_io.write_f(url_dir, home_domain + newline, 'o');
            }

            File temp_f = new File(temp_dir);
            if(!temp_f.exists()){
                file_io.write_f(temp_dir, "1" + newline + home_domain, 'o');    //pointer start from 2 line
                System.out.println("Temp file created & initialized");
            }

            File setting_f = new File(setting_dir);
            if(!setting_f.exists()){
                is_same_site = terminal_io.get_bool("Search on this site only?(T/F) ");
                file_io.write_f(setting_dir, Boolean.toString(is_same_site), 'o');
                inc_media = terminal_io.get_bool("Inc media domain(slower)?(T/F) ");
                file_io.write_f(setting_dir, newline + Boolean.toString(inc_media), 'a');
                is_broad_mode = terminal_io.get_bool("Use broad mode(identify 1&2nd level domain only)?(T/F) ");
                file_io.write_f(setting_dir, Boolean.toString(is_broad_mode), 'a');
                System.out.println("Setting file created");
            }else{
                //read settings
                is_same_site = Boolean.parseBoolean(file_io.read_file(setting_dir, 0));
                inc_media = Boolean.parseBoolean(file_io.read_file(setting_dir, 1));
                is_broad_mode = Boolean.parseBoolean(file_io.read_file(setting_dir, 2));
                System.out.println("Setting file read");
            }
        }catch(Exception e){
            System.out.println(e);
        }

        terminal_io = null;

        long url_pt = Long.parseLong(file_io.read_file(temp_dir, 1));   //retrieve pointer
        URL true_home_domain_url;

        try{
            true_home_domain_url = new URL(file_io.read_file(temp_dir, 2));
            true_home_domain = resolve_home_domain(true_home_domain_url, is_broad_mode);
        }catch(Exception e){
            System.out.println(e);
        }
        

        File pause_f = new File(pause_dir);
        while(file_io.read_file(url_dir, url_pt) != file_io.eof_sign && !pause_f.exists()){
            try{
                Boolean skip_this_url = false;
                URL url_link = new URL(file_io.read_file(url_dir, url_pt));
                String url_link_strg = url_link.toString();
                home_domain = url_link.getProtocol() + "://" + url_link.getHost();
                
                if(url_link_strg.lastIndexOf(".")!= -1){
                    String suffix = url_link_strg.substring(url_link_strg.lastIndexOf(".") + 1, url_link_strg.length()).toLowerCase();
                    for(String skip_suffix : skip_suffixs){
                        if(suffix.equals(skip_suffix.toLowerCase())){
                            skip_this_url = true;
                            System.out.println("Skipped search: " + url_link_strg + "[in skip suffix]");
                            break;
                        }
                    }
                }



                // System.out.println("Now: " + url_link); //testing

                if(!skip_this_url){
                    BufferedReader bf_reader = new BufferedReader(new InputStreamReader(url_link.openStream(), "UTF-8"));
                    String read_line = "";
                    boolean is_end = false;
                    boolean add_start = false;    //count '"'
                    boolean found_tag = false;
                    String temp_link = "";
                    boolean is_ref_tag = false;
                    
                    do{
                        read_line = bf_reader.readLine();
                        //file_io.write_f("/home/laiyuan/Desktop/Coding/using/download/libretext/test.txt", read_line + newline, 'a'); //test
                        //System.out.println(read_line);   //testing
                        is_end = (read_line == null);
                        if(!is_end){
                            String line_arr[] = read_line.split("\"");
                            // int count_quo = link_function.count_target(read_line, "\"");
                            ArrayList<String> link_arr = new ArrayList<String>();
                            
                            /** ------this is replaced code------------
                            int i = -1;
                            if(has_open_quo){
                                i = 0;
                            }else{
                                i = 1;
                            }
                            while(i < line_arr.length){
                                if(has_open_quo){
                                    temp_link = temp_link + line_arr[i];
                                    link_arr.add(temp_link);
                                    has_open_quo = false;
                                }else if(i == line_arr.length - 1){
                                    temp_link = line_arr[i];
                                    has_open_quo = true;
                                }else{
                                    link_arr.add(line_arr[i]);
                                }
                                i = i + 2;
                            }
                            */

                            for(int i = 0; i < line_arr.length - 1; i++){
                                /**
                                if(line_arr[i+1].indexOf("https://batch") != -1){
                                    System.out.print("GOTU");
                                }//test
                                */
                                String this_sep = line_arr[i];
                                found_tag = false;
                                for(String tag : tags){
                                    if(this_sep.replaceAll("\\s", "").toLowerCase().indexOf(tag.replaceAll("\\s", "").toLowerCase()) != -1){
                                        is_ref_tag = ref_tag.equals(tag);
                                        found_tag = true;
                                        break;
                                    }
                                }
                                if(i == 0 && add_start){
                                    temp_link = temp_link + this_sep;
                                    link_arr.add(temp_link);
                                    add_start = false;
                                }else if(i == line_arr.length - 2 && found_tag){
                                    temp_link = line_arr[i+1];
                                    add_start = true;
                                }else if(found_tag){
                                    link_arr.add(line_arr[i+1]);
                                    i++;
                                }

                            }
                            //-------end of replacement--------------
                            
                            //search if repeated link
                            File url_f = new File(url_dir);
                            BufferedReader f_sc = new BufferedReader(new FileReader(url_f));
                                                
                            for(int j = 0; j < link_arr.size(); j++){
                                boolean found = false;
                                String url_strg = link_arr.get(j);
                                
                                //custom code
                                for(int i = 0; i < replace_list.length; i++){
                                    url_strg = url_strg.replaceAll(replace_list[i], with_list[i]);
                                }
                                //end of custom code

                                //check if direct to othrer domain
                                boolean has_protocol = false;
                                for(String protocol : protocols){
                                    if(url_strg.indexOf(protocol) != -1){
                                        has_protocol = true;
                                        break;
                                    }
                                }

                                //p.s. inc media: distinguish href and link to other media , e.g. src=<video> <-> not inc
                                if(is_ref_tag || inc_media){
                                    url_strg = url_remove_heas_tail_slash(url_strg);
                                    boolean has_home_domain = (url_strg.indexOf(home_domain) != -1);
                                    //add home domain
                                    if(!has_home_domain){
                                        if(!has_protocol){
                                                url_strg = home_domain + url_sep + url_strg;
                                        }
                                    }
                                }else if(has_protocol){
                                    //link ref other from href
                                    url_strg = url_remove_heas_tail_slash(url_strg);
                                }
                                
                                found = find_line_file(url_dir, url_strg);
                                // f_sc.reset();
                                if(!found){
                                    //standardise url
                                    /**
                                    boolean has_protocol = false;
                                    for(String protocol : protocols){
                                    if(url_strg.indexOf(protocol) != -1){
                                        has_protocol = true;
                                        break;
                                    }
                                }
                                */
                                
                                /**
                                 if(!has_protocol){
                                     url_strg = default_protcol + url_strg;
                                }
                                */
                                    boolean add_url = false;
                                    //check if url_link has home domain <-> same site?
                                    //if(is_same_site && (is_ref_tag || has_protocol) && url_strg.indexOf(true_home_domain) == -1){
                                    if(is_same_site && (is_ref_tag || has_protocol)){
                                        URL temp_url = new URL(url_strg);
                                        if(!resolve_home_domain(temp_url, is_broad_mode).equals(true_home_domain)){
                                            //if same site && !found home domain
                                            System.out.println("Skipped: " + url_strg + "[outside domain]");
                                        }else{
                                            add_url = true;
                                        }
                                    }else if(is_valid_url(url_strg) || !is_ref_tag){
                                        add_url = true;
                                    }
                                    if(add_url){
                                        file_io.write_f(url_dir, url_strg + newline, 'a');
                                        System.out.println("Found: " + url_strg); //uncommon to be quiet
                                    }
                                }
                            }
                            f_sc.close();
                            


                        }                
                    }while(!is_end);
                }
            }catch(Exception e){
                System.out.println(e);
            }
            url_pt++;
            file_io.change_f_line(temp_dir, Long.toString(url_pt), 1);  //update url pointer
        }


        if(pause_f.exists()){
            System.out.println("Paused");
        }else if(file_io.read_file(url_dir, url_pt) == file_io.eof_sign){
            System.out.println("Finished");
        }
    }

    static String resolve_home_domain(URL url, boolean is_broad_mode){ //broad mode: check second level domain --> eg.edu.hk = eg2.edu.hk
        String host_strg = "";
        try{
            if(is_broad_mode){
                host_strg = url.getHost();
                String host_split[] = host_strg.split("\\.");
                host_strg = host_split[host_split.length-2] + "." + host_split[host_split.length-1];
                host_strg = host_strg.toLowerCase();
            }else{
                host_strg = url.getHost();
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return host_strg;
    }

    static String url_remove_heas_tail_slash(String url_strg){
        switch(url_strg.charAt(0)){
            case '/':
                //avoid duplicate /
                int i = 1;
                while(url_strg.charAt(i) == '/' && i < url_strg.length()){
                    i++;
                }
                url_strg = url_strg.substring(i,url_strg.length());
                break;
        }
        switch(url_strg.charAt(url_strg.length()-1)){
            case '/':
                //avoid duplicate /
                int i = url_strg.length()-2;
                while(url_strg.charAt(i) == '/' && i > 0){
                    i--;
                }
                url_strg = url_strg.substring(0, i+1);
                break;
        }
        return url_strg;
    }

    static boolean is_valid_url(String url){
        boolean valid = false;
        try{
            URL the_url = new URL(url);
            the_url.toURI();
            valid = true;
        }catch(Exception e){
            // System.out.println(e);
        }
        return valid;
    }

    static boolean find_line_file(String dir, String strg){
        boolean found = false;
        try{
            File f = new File(dir);
            Scanner f_in = new Scanner(f, "UTF-8");
            while(f_in.hasNext() && !found){
                String in_strg = f_in.nextLine();
                found = (strg.equals(in_strg));
            }
        }catch(Exception e){
            System.out.println("downloader class: main, find_line_file has error!");
            System.out.println(e);
        }
        return found;
    }


}
class Link_Function{

    String replace_all_with(String strg, String replace_this, String with_this){
        String output = "";
        int i = 0;
        int copy_start = 0;
        while(i <= strg.length() - replace_this.length()){

            int j = 0;
            boolean match = true;
            while(j < replace_this.length() && match){
                match = (strg.charAt(i+j) == replace_this.charAt(j));
                j++;
            }
            if(match){
                String temp_strg = "";
                int a = copy_start;
                while(a < i){
                    temp_strg = temp_strg + strg.charAt(a);
                    a++;
                }
                temp_strg = temp_strg + with_this;
                output = output + temp_strg;
                copy_start = i + replace_this.length();
            }
            i = i + j;
        }
        return output;
    }

    //find number of targets inside input content
    int count_target(String content, String target){
        int n = 0;
        int i = 0;
        while(i <= content.length() - target.length()){
            boolean match = true;
            int j = 0;
            while(j < target.length() && match){
                match = (content.charAt(i + j) == target.charAt(j));
                j++;
            }
            if(match){
                n++;
            }
            i = i + j;
        }
        return n;
    }
}


class Termainal_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    Scanner in = new Scanner(System.in);

    boolean get_bool(String description){
        boolean output = false;
        boolean valid = false;
        do{
            System.out.print(description);
            String input = in.nextLine();
            switch(input){
                case "t":
                case "T":
                case "1":
                case "True":
                case "TRUE":
                case "true":
                    output = true;
                    valid = true;
                    break;
                case "f":
                case "F":
                case "0":
                case "False":
                case "FALSE":
                case "false":
                    output = false;
                    valid = true;
                    break;

            }
        }while(!valid);
        return output;
    }

    //the return dir may or may not has 'sep'
    String get_dir(){
        File file;
        String dir = "";
        boolean is_first = true;
        do{
            if(!is_first){
                System.out.println("Invalid dir. Try again!");
                print_line_sep();
            }
            is_first = false;
            System.out.print("Enter dir: ");
            dir = in.nextLine();
            //add 'sep' if missing
            if(dir.charAt(dir.length()-1) != sep){
                dir = dir + sep;
            }
            file = new File(dir);
        }while(!file.isDirectory());
        return dir;
    }
    
    void print_line_sep(){
        System.out.println("--------------------------------------");
    }
}

class File_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    public static String eof_sign = "\n!!!EOF!!!";

    String read_file(String path, long line){    //line begin at 1
        String content = "";
        try{
            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            long i = 0;
            do{
                content = fr.nextLine();
                i++;
            }while(i < line && fr.hasNextLine());
            fr.close();
            if(i < line){
                content = eof_sign;
            }
        }catch(Exception e){
            System.out.println("File_IO Class: read_file has error!");
            System.out.println(e);
        }
        return content;
    }

    void change_f_line(String path, String content, int line){
        try{
            ArrayList<String> file_content = new ArrayList<String>();

            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            for(int i = 1; fr.hasNextLine(); i++){  //i: current line
                if(i == line){
                    //replace the line
                    fr.nextLine();
                    file_content.add(content);
                }else{
                    file_content.add(fr.nextLine());
                }
            }
            fr.close();
            //FileWriter fw = new FileWriter(file, false);
            FileOutputStream out = new FileOutputStream(file, false);
            OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
            for(int i = 0; i < file_content.size(); i++){
                fw.write(file_content.get(i));
                if(i != file_content.size() - 1){
                    fw.write(newline);
                }
            }
            fw.close();
        }catch(Exception e){
            System.out.println("File_IO Class: change_f_line has error!");
            System.out.println(e);
        }
    }
    
    void write_f(String path, String content, char mode){
        File file = new File(path);

        if(file.exists()){
            boolean perserve_content = true;
            switch(mode){
                case 'a':   //append mode
                case 'A':
                        perserve_content = true;
                        break;
                case 'o':   //overwrite mode
                case 'O':
                        perserve_content = false;
                        break;
            }
            try{
                //FileWriter fw = new FileWriter(file, perserve_content);
                FileOutputStream out = new FileOutputStream(file, perserve_content);
                OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
                fw.write(content);
                fw.close();
                // System.out.println("written to file: " + path);  //uncommon to be noisy
            }catch(Exception e){
                System.out.println("File_IO Class: write_f has error!");
                System.out.println(e);
            }
        }else{
            try{
                file.createNewFile();
                // FileWriter fw = new FileWriter(file);
                FileOutputStream out = new FileOutputStream(file);
                OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
                fw.write(content);
                fw.close();
                System.out.println("File created: " + path);
            }catch(Exception e){
                System.out.println("File_IO Class: write_f() has error!");
                System.out.println(e);
            }
        }
    }
}