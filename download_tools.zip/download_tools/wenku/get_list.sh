#!/bin/bash
find . -type f | xargs grep "^<" | sed -e "s/^..//g" -e "s/..$//g" -e "s/:</\t/g" | sort -n > ../-1_index.txt