import java.util.Scanner;
import java.util.ArrayList; 
import javax.smartcardio.TerminalFactory;

import java.io.File;
import java.io.FileWriter;;

class txt_wenku{
    public static void main(String args[]){
        final String space_sep = "\t";
        final int filename_line = 3;
        final Long max_file_index = 9999L;

        final String newline = System.getProperty("line.separator");

        Termainal_IO termain_io = new Termainal_IO();
        System.out.println("Enter dir contain txt file.");
        String in_dir = termain_io.get_dir();
        String out_dir = "";
        
        File temp_file;
        try{
            do{
                System.out.print("Enter dir of output file: ");
                out_dir = termain_io.in.nextLine();
                temp_file = new File(out_dir);
                if(temp_file.exists()){
                    if(termain_io.get_bool("File already exists. Rewrite file?(T/F): ")){
                        //rewrite
                        FileWriter fw = new FileWriter(temp_file);
                        fw.write("");
                        fw.close();
                    }
                }else{
                    temp_file.createNewFile();
                    System.out.println("File created");
                }
            }while(!temp_file.exists());
        }catch(Exception e){
            System.out.println("class txt_wenku: main has error!");
        }
        temp_file = null;
        


        System.out.println("Input dir is: " + in_dir);
        System.out.println("Output dir is: " + out_dir);
    

        termain_io = null;

        File_IO file_io = new File_IO();
        for(long i = 0L; i <= max_file_index; i++){
            String file_dir = in_dir + Long.toString(i);
            String filename = "";
            System.out.print("Getting file: " + file_dir);
            try{
                File in_f = new File(file_dir);
                if(in_f.exists()){
                    filename = file_io.read_file(file_dir, filename_line);
                    //custom file name
                    filename = filename.substring(1, filename.length()-1);
                    //end of custom
                    file_io.write_f(out_dir, i + space_sep + filename + newline, 'a');
                    System.out.println(" [Success]");
                }else{
                    System.out.println(" [Not exist]");
                }
            }catch(Exception e){
                System.out.println(" [Error]");
            }
        }
        
        
    }
}


class Termainal_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    Scanner in = new Scanner(System.in);

    boolean get_bool(String description){
        boolean output = false;
        boolean valid = false;
        do{
            System.out.print(description);
            String input = in.nextLine();
            switch(input){
                case "t":
                case "T":
                case "1":
                case "True":
                case "TRUE":
                case "true":
                    output = true;
                    valid = true;
                    break;
                case "f":
                case "F":
                case "0":
                case "False":
                case "FALSE":
                case "false":
                    output = false;
                    valid = true;
                    break;

            }
        }while(!valid);
        return output;
    }

    //the return dir may or may not has 'sep'
    String get_dir(){
        File file;
        String dir = "";
        boolean is_first = true;
        do{
            if(!is_first){
                System.out.println("Invalid dir. Try again!");
                print_line_sep();
            }
            is_first = false;
            System.out.print("Enter dir: ");
            dir = in.nextLine();
            //add 'sep' if missing
            if(dir.charAt(dir.length()-1) != sep){
                dir = dir + sep;
            }
            file = new File(dir);
        }while(!file.isDirectory());
        return dir;
    }
    
    void print_line_sep(){
        System.out.println("--------------------------------------");
    }
}

class File_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    public static String eof_sign = "\n!!!EOF!!!";

    String read_file(String path, long line){    //line begin at 1
        String content = "";
        try{
            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            long i = 0;
            do{
                content = fr.nextLine();
                i++;
            }while(i < line && fr.hasNextLine());
            fr.close();
            if(i < line){
                content = eof_sign;
            }
        }catch(Exception e){
            System.out.println("File_IO Class: read_file has error!");
            System.out.println(e);
        }
        return content;
    }

    void change_f_line(String path, String content, int line){
        try{
            ArrayList<String> file_content = new ArrayList<String>();

            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            for(int i = 1; fr.hasNextLine(); i++){  //i: current line
                if(i == line){
                    //replace the line
                    fr.nextLine();
                    file_content.add(content);
                }else{
                    file_content.add(fr.nextLine());
                }
            }
            fr.close();
            FileWriter fw = new FileWriter(file, false);
            for(int i = 0; i < file_content.size(); i++){
                fw.write(file_content.get(i));
                if(i != file_content.size() - 1){
                    fw.write(newline);
                }
            }
            fw.close();
        }catch(Exception e){
            System.out.println("File_IO Class: change_f_line has error!");
            System.out.println(e);
        }
    }
    
    void write_f(String path, String content, char mode){
        File file = new File(path);

        if(file.exists()){
            boolean perserve_content = true;
            switch(mode){
                case 'a':   //append mode
                case 'A':
                        perserve_content = true;
                        break;
                case 'o':   //overwrite mode
                case 'O':
                        perserve_content = false;
                        break;
            }
            try{
                FileWriter fw = new FileWriter(file, perserve_content);
                fw.write(content);
                fw.close();
                System.out.println("written to file: " + path);
            }catch(Exception e){
                System.out.println("File_IO Class: write_f has error!");
                System.out.println(e);
            }
        }else{
            try{
                file.createNewFile();
                FileWriter fw = new FileWriter(file);
                fw.write(content);
                fw.close();
                System.out.println("File created: " + path);
            }catch(Exception e){
                System.out.println("File_IO Class: write_f() has error!");
                System.out.println(e);
            }
        }
    }
}