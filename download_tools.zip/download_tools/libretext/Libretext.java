import java.io.*;
import java.lang.annotation.Target;
import java.lang.reflect.Array;
import java.net.URL;
import java.nio.Buffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;
import java.util.Scanner;



class Libretext{


    public static void main(String args[]){
        //Scanner in = new Scanner(System.in);
        System.out.println("HI");   //testing
        IO_class io = new IO_class(); // I/O object: io & initialize necessary io variable


        int choice = 0;

        do{
            io.print_sep();
            System.out.println("Menu:");
            System.out.println("1: Search suffix");
            System.out.println("2: Download file");
            System.out.print("Choice: ");
            choice = io.input_int(); 
        }while(!((choice >= 1) && (choice <= 2))); //change this if add choice********************************

        io.print_sep();

        switch(choice){
            case  1:    //search for suffix link & filename
                //input raw file of HTML
                System.out.print("Input dir + filename of HTML file (.txt): ");     
                String raw_strg = io.input_file();
                System.out.print("Input suffix for search(without '.'): ");
                io.suffix = io.input_terminal();
                io.initialize_temp();
                System.out.println("Temp file initialized.");

                Algorithm al = new Algorithm(io.suffix, raw_strg); //algorith obj
				


                al.search_link_name();
                al.process_name();
                //al.process_name();

                System.out.println("link: ");
                for(String link: al.link_array){
                    System.out.println(link);
                }
                System.out.println("filename: ");        
                for(String name: al.name_processed){
                    System.out.println(name);
                }
                io.print_sep();
            
                System.out.print("Output link file: ");
                io.output_file(io.strg_array_to_strg(al.link_array));
                io.print_sep();
                

                System.out.print("Output processed name file:");
                io.output_file(io.strg_array_to_strg(al.name_processed));

            break;

            case 2: //download file


                System.out.print("Input link file dir: ");
                String input = io.input_file();
                ArrayList<String> link_array = new ArrayList<String>();
                link_array = io.strg_to_array(input);
        
                System.out.print("Input name file dir: ");
                String input2 = io.input_file();
                ArrayList<String> name_array = new ArrayList<String>();
                name_array = io.strg_to_array(input2);

                int download_choice = 0;
                String download_dir = "";
                do{
                    System.out.println("Download dir? ");
                    System.out.println("1: temp dir");
                    System.out.println("2: other dir(input)");
                    System.out.print("Choice: ");
                    download_choice = io.input_int();
                    if(!((download_choice >= 1) && (download_choice <= 2))){
                        System.out.println("Invalid choice! Try again!");
                        io.print_sep();
                    }
                }while(!((download_choice >= 1) && (download_choice <= 2)));   //change this line if add choice*********************

                switch(download_choice){
                    case 1: //set the same as temp dir
                        download_dir = io.temp_dir_without_filename;
                    break;

                    case 2: //input download dir
                        download_dir = io.input_terminal();
                    break;
                }

                Downloads_class down = new Downloads_class(link_array, name_array, io.finished_up_to, download_dir, io.dir_segment, "." + io.suffix);
                io.finished_up_to = down.download();

                //temp : output finished_up_to
                io.temp_output_finished_up_to();
            
            break;

        }



    }
}





//for input output of file & terminal
class IO_class{
    //class input
    Scanner in_class = new Scanner(System.in);
    
    //for new line
    final String newline = System.getProperty("line.separator");

    String suffix = "";
    int finished_up_to = -1;
    String temp_dir_without_filename = "";
    String temp_dir = ""; //dir of temp file
    final String temp_name = "temp.laiyuan";    //name of temp file
    char dir_segment = 0;
    ArrayList<String> temp_array = new ArrayList<String>();
    ArrayList<String> raw_array = new ArrayList<String>();

    public void print_sep(){
        System.out.println("******************************************************************");
    }



    //input boolean value : T == true ; F == false
    public boolean input_boolean(String question){
        boolean in = false;
        boolean valid = false;
        String strg = "";
        do{
            System.out.print(question);
            strg = input_terminal();
            if((strg.equals("T")) || (strg.equals("t")) || (strg.equals("1"))){
                in = true;
                valid = true;
            }else if((strg.equals("F")) || (strg.equals("f")) || (strg.equals("0"))){
                in = false;
                valid = true;
            }else{
                valid = false;
                System.out.println("Invalid input. Try again.");
            }
        }while(!valid);
        System.out.println();
        return in;
    }

    //input integer
    public int input_int(){
        Scanner in = new Scanner(System.in);
        int input = in.nextInt();
        return input;
    }

    //input from terminal: String
    public String input_terminal(){
        Scanner in = new Scanner(System.in);
        String temp = "";
        temp = in.nextLine();
        //System.out.println();
        return temp;
    }

    //intput dir_segment
    public void input_dir_segment(){
        int choice = -1;
        boolean valid = true;
        final int no_choice = 2;    //number of choice : need to be change if add choice

 
        do{
            if(!valid){
                System.out.println("Invalid output! Try again.");
                print_sep();
            }
            System.out.println("Which System you are using?");
            System.out.println("1.Window");
            System.out.println("2.Linux");
            System.out.print("choice: ");
            choice = in_class.nextInt();
            System.out.println();
            valid = (choice > 0) && (choice <= no_choice);
        }while(!valid);

        switch(choice){
            //window
            case 1: dir_segment = '\\';
                break;
            case 2: dir_segment = '/';
                break;
        }

        
    }
	
    /**
        //input directory
        public String input_dir(){
        // System.out.print("Input directory + file name of raw HTML for searching suffix: ");
            String dir = "";
            dir = input_terminal();
            return dir;
        }
    */


    //input from the file ---------------------------------------------------
    public String input_file(){
        //System.out.print("Input dir + file name:");
        String dir = input_terminal();
        //final String nul = "";    //use for null checking
        String temp = "";
        String merge = "";
        boolean end = false;
        try{
            File in_file = new File(dir);
            Scanner in = new Scanner(in_file, "UTF-8");

            while(!end){
                if(in.hasNextLine()){
                    temp = in.nextLine();
                    merge = merge + newline + temp;
                }else{
                    end = true;
                }
            }
			System.out.println("Input finished!");

            in.close();
        }catch(Exception e){
            System.out.println("input file error");
            System.out.println(e);
        }
        //return value
        return merge;
    }


    public String strg_array_to_strg(ArrayList<String> input){
        String out = "";
        for(String temp : input){
            if(out == ""){
                //first line
                out = out + temp;
            }else{
                out = out + newline + temp;      
            }
        }
        return out;
    }

    //convert string to string arraylist; new line as strg separation mark
    public ArrayList<String> strg_to_array(String input){
        ArrayList<String> out = new ArrayList<String>();
        String temp = "";
        Scanner in = new Scanner(input);

        while(in.hasNextLine()){
            temp = in.nextLine();
            out.add(temp);
        }
        in.close();
        return out;
    }

    //input output directory
    public String input_out_dir(){
        String out = "";
        System.out.print("output directory + filename: ");
        out = input_terminal();
        System.out.println();
        return out;
    }

    //output content to specific dir
    public void output_to(String out, String out_dir){
        boolean has_term = false;
        try{
            File out_file = new File(out_dir);
            FileWriter out_writer = new FileWriter(out_file);
            has_term = input_boolean("Want terminating line(T/F)? ");
            if(has_term){
                out_writer.write(out + newline + newline); //+ terminating line
            }else{
                //no terminating line
                out_writer.write(out); //+ terminating line                
            }
            out_writer.close();
            System.out.println("Output success.");
        }catch(Exception e){
            System.out.println(e);
        }
    }

    //output as txt file ----------------------------------------------------
    public void output_file(String out){
        String out_dir = input_out_dir();
        output_to(out, out_dir);
    }

    public void input_temp_dir(){
        String in_dir = "";
        System.out.print("load temp from dir: ");
        in_dir = input_terminal();
        System.out.println();
        temp_dir_without_filename = in_dir;
        temp_dir = in_dir + dir_segment + temp_name;

    }

    //initialize temp ; use after searched suffix link; since the suffix is entered
    public void initialize_temp(){
        write_temp_ln(suffix);
        write_temp_ln("-1");    //set download_up_to be -1
    }

    //create temp file -------------------------------------------------------------
    public void create_temp(){
        String out_dir = "";
        System.out.print("temp file dir: ");
        out_dir = input_terminal();
        out_dir = out_dir + dir_segment + temp_name;
        System.out.println();
        //create temp file
        try{
            File out_file = new File(out_dir);
            FileWriter out_writer = new FileWriter(out_file);
            out_writer.close();
        }catch(Exception e){
            System.out.println(e);
        }

        temp_dir = out_dir;
    }

    //read from temp file --------------------------------------------------------
    public String read_temp(){
        String merge = "";
        String temp = "";
        boolean end = false;
        try{
            File in_file = new File(temp_dir);
            Scanner in = new Scanner(in_file, "UTF-8");
            do{
                temp = in.nextLine();
                end = (temp == "");
                if((!end) &&(merge != "")){
                    //next line
                    merge = merge + newline + temp;
                }else if(merge == ""){
                    //first time excute
                    merge = merge + temp;
                }
            }while(!end);
            in.close();
        }catch(Exception e){
          //  System.out.println(e);
        }
        return merge;
    }

    public void temp_output_finished_up_to(){
        input_temp_array();
        temp_array.set(1, String.valueOf(finished_up_to));
        String temp_strg = strg_array_to_strg(temp_array);
        overwrite_temp(temp_strg);
    }

    //input temp content to temp_array
    public void input_temp_array(){
        temp_array = strg_to_array(read_temp());
    }

    //overwrite the temp file
    public void overwrite_temp(String input){
        try {
            File out_file = new File(temp_dir);
            FileWriter out_writer = new FileWriter(out_file);
            out_writer.write(input);
            out_writer.close();
            
        }catch(Exception e) {
            
        }
    }

    //write content (add) to temp ------------------------------------------
    public void write_temp_strg(String strg){
        String temp = "";
        try{
            //read from original file
            temp = read_temp();
            temp = temp + strg; //merge: add new content into temp file

            File out_file = new File(temp_dir);
            FileWriter out_writer = new FileWriter(out_file);
            out_writer.write(temp);
            out_writer.close();
            
        }catch(Exception e){
            System.out.println(e);
        }
    }

    //p.s. input "" : null for blank new-line
    //writeln to temp file ---------------------------------------------------
    public void write_temp_ln(String strg){
        write_temp_strg(strg + newline + newline);
    }

    //constructor
    public IO_class(){
        input_dir_segment();
        print_sep();
        //menu : temp
        int choice = -1;
        boolean valid = false;

        do{
            System.out.println("create temp file or load? ");
            System.out.println("1.create");
            System.out.println("2.load");
            System.out.print("choice: ");
            choice = in_class.nextInt();
            System.out.println();
            
            if(choice == 1){
                //create
                create_temp();
                valid = true;
            }else if(choice == 2){
                //input temp dir
                input_temp_dir();
                valid = true;

                //load from temp file
                input_temp_array();
                //load: suffix
                suffix = temp_array.get(0);
                //load: finished up to download query
                finished_up_to = Integer.parseInt(temp_array.get(1));

            }else{
                valid = false;
                System.out.println("Invalid input. Enter again!");
            }
            print_sep();
        }while(!valid);

    }
}


class Algorithm{
    final char dot = '.';
    final char col = '"';
	String strg = "";	//string for searching
    final String newline = System.getProperty("line.separator");

    String suffix = "";
    ArrayList<String> link_array = new ArrayList<String>();   //link of target suffix
    ArrayList<String> name_array = new ArrayList<String>();   //file name of the suffix file (raw)
    ArrayList<String> name_processed = new ArrayList<String>(); //processed  file name
    
    //constructor
    public Algorithm(String suffix_in, String strg_in){
        suffix = suffix_in;
		strg = strg_in;
    }

    //find target pos in inputted string; return -1 if not found
    //p.s. include start_pos
    public int find_target_pos(final String strg, final char target_ch, final int start_pos){
        int target_pos = -1;
        char temp_ch = 0;
        for(int i = start_pos; i < strg.length(); i++){
            temp_ch = strg.charAt(i);
            if(temp_ch == target_ch){
                //found
                target_pos = i;
                break;
            }
        }
        return target_pos;
    }

    //check if there is the reqiured suffix inside input string
    public boolean check_suffix_match(final String strg, final int dot_pos){
        boolean match = true;
        char temp_ch = 0;
        int i = 0; //counter
        if(!strg.equals("")){
            //string is not null
            while((i < strg.length()) && (i < suffix.length())){

                temp_ch = strg.charAt(i + dot_pos + 1);
                if(!(temp_ch == suffix.charAt(i))){
                    //not match
                    match = false;
                    break;
                }
                i++;
            }
            if(dot_pos == strg.length() - 1){
                //dot is last char in strg
                match = false;
            }
        }else{
            match = false;
        }
        return match;
    }

    //return col_pos when given mid pos: [start col, end_col]
    //p.s. X search start_pos
    //p.s. return -1 if col not found
    public int[] find_col_mid(final String strg, final int start_pos){
        int[] col_pos = new int[2];
        col_pos[0] = -1;
        col_pos[1] = -1;
        if(!(strg.equals("")) && (start_pos + 1 < strg.length() ) && (start_pos - 1 >= 0)){
            //not empty & *** : at least 3 char
            //find end_col
            for(int i = start_pos + 1; i < strg.length(); i++){

				//System.out.println( i + ":: " + strg.charAt(i));//testing
				
                if(strg.charAt(i) == col){
					//System.out.println( start_pos + " close col Found");//tesing
                    //found end_col
                    col_pos[1] = i;
					break;

                }
            }
            //find open_col
            for(int i = start_pos - 1; i >= 0; i--){
				
				//System.out.println(i + " :: " + strg.charAt(i));//testing
				
                if(strg.charAt(i) == col){
					//System.out.println(start_pos + "open col Found");//testing
                    //found open col
                    col_pos[0] = i;
					break;

                }
            }
        }
        return col_pos;
    }

    //return col_pos before the start pos in given strg (exclusive the start_pos): [start col, end col]
    //p.s. return -1 if not found
    public int[] find_col_before(final String strg, final int start_pos){
        int[] col_pos = new int[2];
        col_pos[0] = -1;
        col_pos[1] = -1;
        int col_index = 1;  //end col:1 ; open col :0; == -1 when all col found
        if(start_pos - 1 >= 0){
            for(int i = start_pos - 1; i >= 0; i--){
                if(strg.charAt(i) == col){
                    col_pos[col_index] = i;
                    col_index--;
                    if(col_index == -1){
                        //all col found
                        break;
                    }					
                }
            }
        }
        return col_pos;
    }

    //return strg between start_pos and end_pos(exclusively) of input string
    //p.s. return "" if start_pos == end_pos 		|| 			start_pos || end_pos == -1
    public String extract_between(final String strg, final int start_pos, final int end_pos){
        String out = "";
	if((start_pos >= 0) && (end_pos >- 0) && (start_pos < strg.length()) && (end_pos < strg.length())){
			if(!(start_pos == end_pos)){
				for(int i = start_pos + 1; i < end_pos; i++){
					out = out + strg.charAt(i);
				}
			}//else return null (initizlised)
		}
        return out;
    }

    //check if input link is a vlid link(contain http)
    public boolean check_valid_link(final String link){
        final String head = "http";
        boolean valid_link = true;
        int i = 0; //counter
        if(!link.equals("")){
            //link is not null
            while((i < link.length()) && (i < head.length())){
                if(!(head.charAt(i) == link.charAt(i))){
                    valid_link = false;
                }
                i++;
            }
        }else{
            //is null input
            valid_link = false;
        }
        return valid_link;
    }

    public void search_link_name(){
        int dot_pos = -1;   //dot pos in input String
        int[] link_col_pos = new int[2];
        int[] name_col_pos = new int[2];
        String link = "";
        String name = "";
		
		while(dot_pos < strg.length()){
			dot_pos = find_target_pos(strg, dot, dot_pos + 1);
			if(dot_pos != -1){
				//System.out.println(dot_pos);//testing
				//dot found
				link_col_pos = find_col_mid(strg, dot_pos);
				if(check_suffix_match(strg, dot_pos)){
					link = extract_between(strg, link_col_pos[0], link_col_pos[1]);
					if(check_valid_link(link)){
						//p.s. below need change if site structure change ******************************************
						name_col_pos = find_col_before(strg, link_col_pos[0]);
						name_col_pos = find_col_before(strg, name_col_pos[0]);
						name_col_pos = find_col_before(strg, name_col_pos[0]);
						//end of change
						name = extract_between(strg, name_col_pos[0], name_col_pos[1]);					
						
						link_array.add(link);
						name_array.add(name);
						
					}
				}
				
			}else{
				//no more dot found
				break;
			}
		}
	
	
   }
	
    public void process_name(){
        int invalid_count = 1;
        int slash_pos = -1;
        final String invalid_symbol = "!";
        final char slash = '/';
        String name_out = "";
        String name_temp = "";

        for(String name : name_array){
            name_out = "";
            name_temp = "";
            slash_pos = -1;

            if(check_valid_link(name)){
                //is a valid link
                //cut the filename out //p.s. below need change if site structure change************************
                slash_pos = find_target_pos(name, slash, 0);
                slash_pos = find_target_pos(name, slash, slash_pos + 1);
                slash_pos = find_target_pos(name, slash, slash_pos + 1);
                //end of change
                if(slash_pos + 1 < name.length()){
                    //valid slash_pos
                    //cut file name out (til the end of name link)
                    for(int i = slash_pos + 1; i < name.length(); i++){
                        name_temp = name_temp + name.charAt(i);   //not include slash at slash_pos
                    }
                    //replace filename : insert "[]"
                    name_out = "[";     //add "[" at beg of filename
                    for(int i = 0; i < name_temp.length(); i++){
                        if(name_temp.charAt(i) == slash){
                            //slash found  --> add "]["
                            name_out = name_out + "][";
                        }else{
                            //copy into name_out
                            name_out = name_out + name_temp.charAt(i);
                        }
                    }
                    name_out = name_out + "]"; //add "]" at last of the file name
                }else{
                    //invalid slash_pos
                    name_out = invalid_symbol + Integer.toString(invalid_count);
                    invalid_count++;
                }
            }else{
                name_out = invalid_symbol + Integer.toString(invalid_count);
                invalid_count++;
            }
            name_processed.add(name_out);
        }
    }



}

class Downloads_class{
    ArrayList<String> link = new ArrayList<String>();
    ArrayList<String> name = new ArrayList<String>();
    int finished_up_to = -1;
    int current_down = -1;
    String suffix = ""; //suffix for downloaded file
    String dir = "";    //down load dir
    char dir_segment = 0;
    final String pause_file = "pause.laiyuan";

    //constructor
    public Downloads_class(ArrayList<String> link_array, ArrayList<String> name_array,int finished_download_index, String down_directory, char dir_segment_ch, String file_suffix){ 
        link = link_array;
        name = name_array;
        finished_up_to = finished_download_index;
        dir = down_directory;
        dir_segment = dir_segment_ch;
        suffix = file_suffix;
    }

    public int download(){
        //check if pause file exits
        while((!new File(dir + dir_segment + pause_file).isFile()) && (finished_up_to + 1 < link.size())){
            current_down = finished_up_to + 1;

            try {
                if(!((name.get(current_down).equals("")) || (link.get(current_down).equals("")))){    //link is not empty
                    if(name.get(current_down).charAt(0) == '!'){
                    //error link 
                    finished_up_to++;    //skip this error link
                        continue;
                    }

                    System.out.print("Downloading[" + current_down + "/" + (link.size() - 1) + "]: " + link.get(current_down));

                    URL url_link = new URL(link.get(current_down));
                    ReadableByteChannel rbc = Channels.newChannel(url_link.openStream());
                    FileOutputStream fos = new FileOutputStream(dir + dir_segment + name.get(current_down) + suffix);
                    fos.getChannel().transferFrom(rbc, 0 ,Long.MAX_VALUE);
                    
                    System.out.println(" [Finished]");
                    //close
                    rbc.close();
                    fos.close();
                }


                    finished_up_to++;
            }catch(Exception e) {
                System.out.println(" [Error]");
		finished_up_to++;	//skip this link
            }

        }

        //paused
        System.out.println("Sucessfully paused!");
        return finished_up_to;
    }
    
    
}


//p.s. detect if temp already exit: prevent overwrite
//p.s. add int check in int input of IO_Class

//bug: -1 not change in temp file after downloading
