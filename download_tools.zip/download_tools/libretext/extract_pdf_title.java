import java.io.File; 
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;




class extract_pdf_title{
   static Scanner in = new Scanner(System.in);
   static int counter = 0;
   static final String newline = System.getProperty("line.separator");
   static final String sep = System.getProperty("file.separator");

   public static void main(String args[]) throws IOException {
      File folder;
      boolean is_dir = false;
      do{
         System.out.print("Folder: ");
         String dir = "";
         dir = in.nextLine();
         folder = new File(dir);
         is_dir = folder.isDirectory();
         if(!is_dir){
            System.out.println("Not a dir. Try again!");
         }
      }while(!is_dir);
      System.out.println("Dir: " + folder.getAbsolutePath());
      if(get_bool("Proceed(T/F)?")){
         process(folder);
      }
   }

   static final String target_suffix = "pdf";

   static void process(File folder){
      for(final File File_entery : folder.listFiles()){
         String path = folder.getAbsolutePath();
         if(File_entery.isDirectory()){
            process(File_entery);
         }else{
            String name = File_entery.getName();
            //String suffix = "";
            String suffix = name.substring(name.lastIndexOf(".") + 1, name.length());
            if(suffix.equals(target_suffix)){
               String title = get_title(File_entery).toLowerCase();
               title = title.replace("/", "|");
               int name_counter = 0;
               File new_f;
               do{
                  new_f = name_counter == 0 ? new File(path + sep + title + "." + target_suffix) : new File(path + sep + title + "(" + name_counter + ")." + target_suffix);
                  name_counter++;
               }while(new_f.exists());
               Boolean success = File_entery.renameTo(new_f);
               System.out.print(success ? "[Success]" : "[Fail]");
               //System.out.println("file name: " + name + newline + "   title: " + title);
               System.out.println(name + newline + "  \\——>" + title);

            }
         }
      }
   }

   static String get_title(File file){
	   final String target_word = "book:";
      final int start_page = 1;
      final int end_page = 1;
      String title = "";
      //Loading an existing document
      try{
         //File file = new File(file_dir);
         PDDocument document = PDDocument.load(file);

         //Instantiate PDFTextStripper class
         PDFTextStripper pdfStripper = new PDFTextStripper();
         pdfStripper.setStartPage(start_page);
         pdfStripper.setEndPage(end_page);

         //Retrieving text from PDF document
         String text = pdfStripper.getText(document);
         document.close();
         //System.out.println(text);
         String lines[] = text.split(newline);
         /**
         for(int i = 0; i < 20; i++){
            System.out.println(lines[i]);
         }
         */
         //String title = lines[0].toLowerCase();
         //System.out.println(title);
         if(lines[0].toLowerCase().indexOf(target_word) != -1){
            lines[0] = lines[0].substring(lines[0].toLowerCase().indexOf(target_word) + target_word.length() + 1, lines[0].length());
         }

         for(String line : lines){
            if(is_most_upper_case(line)){
               title += line;
            }else{
               break;
            }
         }
      }catch(Exception e){
         System.out.println(e);
      }
      return title;
   }

   static boolean get_bool(String description){
      boolean output = false;
      boolean valid = false;
      do{
          System.out.print(description);
          String input = in.nextLine();
          switch(input){
              case "t":
              case "T":
              case "1":
              case "True":
              case "TRUE":
              case "true":
                  output = true;
                  valid = true;
                  break;
              case "f":
              case "F":
              case "0":
              case "False":
              case "FALSE":
              case "false":
                  output = false;
                  valid = true;
                  break;

          }
      }while(!valid);
      return output;
  }

   static boolean is_most_upper_case(String input){
      float critical_value = 0.75f;
      float counter = 0.0f;
      float len = 0.0f;
      for(int i = 0; i < input.length(); i++){
         char ch = input.charAt(i);

         if(ch >= 'a' && ch <= 'z'){
            len++;
         }else if(ch <= 'Z' && ch >= 'A'){
            counter++;
            len++;
         }
      }
      //System.out.println("Counter: " + counter + " Len: " + len + "%: " + counter / len);
      if(len == 0){
         return true;
      }else{
         return counter/len >= critical_value;
      }
   }
}