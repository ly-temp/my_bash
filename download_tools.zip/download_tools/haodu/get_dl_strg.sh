#!/bin/bash
#work for file explorer url only; output dl_strg.list
#$file_of_all_urls
function cut_part(){
	awk -F '/' '{print $(NF-1) "/" $NF}' | cut -d'.' -f1 | sort | uniq
}
function cut_fullpart(){
	awk -F '/' '{print $(NF-1) "/" $NF}' | sort | uniq
}
>miss.list
>epub.list
grep ".epub$" "$1" | tee >(cut_fullpart > dl_strg.list) | cut_part > epub.list
cat "$1" | cut_part > full.list
while read -r full;do
	if ! grep -q "$full" "epub.list"
	then echo "$full" >> miss.list
	fi
done < full.list
while read -r miss;do
	grep -m1 -E "${miss}\." "$1" | cut_fullpart  >> dl_strg.list
done < miss.list
