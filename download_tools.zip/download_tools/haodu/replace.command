︽ --> 《
︾ --> 》
﹁ --> 「
﹂ --> 」
︵ --> （
︶ --> ）
｜ --> ——
︻ --> 【
︼ --> 】

iconv -f BIG-5 -t UTF8 -c <in_f> > <out_f>
//find . -type f -name '*.pdb' -exec iconv -f BIG-5 -t UTF8 -c "{}" -o "{}".txt \;
find . -type f -name '*.pdb' -exec sh -c 'iconv -f BIG-5 -t UTF8 -c "$1" -o "${1%.pdb}.txt"' sh {} \;
find . -type f -name '*.txt' | xargs sed -i -e 's/︽/《/g' -e 's/︾/》/g' -e 's/﹁/「/g' -e 's/﹂/」/g' -e 's/︵/（/g' -e 's/︶/）/g' -e 's/｜/——/g' -e 's/︻/【/g' -e 's/︼/】/g'
java extract_title | tee -a <log>