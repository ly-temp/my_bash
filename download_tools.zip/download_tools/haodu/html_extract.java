import java.io.File;
import java.util.Scanner;

import javax.smartcardio.TerminalFactory;

class html_extract{
    static Scanner in = new Scanner(System.in);
    static String target = "<a href=";
    public static void main(String args[]){
        try{
            File_IO file_io = new File_IO();
            Termainal_IO terminal_io = new Termainal_IO();
            File html_f;
            String out_f_dir = "";
            do{
                System.out.print("Enter HTML file dir:");
                html_f = new File(in.nextLine());
            }while(!html_f.exists() || !html_f.isFile());

            do{
                System.out.print("Enter out file dir:");
                out_f_dir = in.nextLine();
                File out_f = new File(out_f_dir);
            }while(!terminal_io.get_bool("Out file dir: " + out_f_dir + " (T/F)?"));

            Scanner fr = new Scanner(html_f, "UTF-8");
            while(fr.hasNext()){
                String line = fr.nextLine();
                String splits[] = line.split("\"");
                for(int i = 0; i < splits.length - 1; i++){
                    if(splits[i].indexOf(target) != -1){
                        i++;
                        String word = splits[i];
                        //System.out.println(splits[i]);
                        int dot_index = word.indexOf(".");
                        if(dot_index == -1){
                            continue;
                        }
                        String upper_sub_strg = word.substring(0, dot_index);
                        if(!find_in_standard_f(out_f_dir, upper_sub_strg)){
                            if(word.charAt(0) == 'V'){
                                String sub_strg = word.substring(1, dot_index);
                                System.out.println(sub_strg);
                                if(!find_in_standard_f(out_f_dir, sub_strg)){
                                    file_io.write_f(out_f_dir, word + terminal_io.newline, 'a');
                                }else{
                                    System.out.println("Fale: " + word);
                                }
                            }else{
                                file_io.write_f(out_f_dir, word + terminal_io.newline, 'a');
                            }
                        }
                        //find_in_standard_f(, target);
                    }
                }
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }

    static Boolean find_in_standard_f(String file_dir, String target){
        Boolean found = false;
        try{
            File file = new File(file_dir);
            Scanner fr = new Scanner(file, "UTF-8");
            while(fr.hasNext()){
                String line = fr.nextLine();
                line = line.substring(0, line.indexOf("."));
                if(line.equals(target)){
                    found = true;
                }
            }
        }catch(Exception e){
            System.out.println(e);

        }
        return found;
    }
}

class File_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    public static String eof_sign = "\n!!!EOF!!!";

    String read_file(String path, long line){    //line begin at 1
        String content = "";
        try{
            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            long i = 0;
            do{
                content = fr.nextLine();
                i++;
            }while(i < line && fr.hasNextLine());
            fr.close();
            if(i < line){
                content = eof_sign;
            }
        }catch(Exception e){
            System.out.println("File_IO Class: read_file has error!");
            System.out.println(e);
        }
        return content;
    }

    void change_f_line(String path, String content, int line){
        try{
            ArrayList<String> file_content = new ArrayList<String>();

            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            for(int i = 1; fr.hasNextLine(); i++){  //i: current line
                if(i == line){
                    //replace the line
                    fr.nextLine();
                    file_content.add(content);
                }else{
                    file_content.add(fr.nextLine());
                }
            }
            fr.close();
            //FileWriter fw = new FileWriter(file, false);
            FileOutputStream out = new FileOutputStream(file, false);
            OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
            for(int i = 0; i < file_content.size(); i++){
                fw.write(file_content.get(i));
                if(i != file_content.size() - 1){
                    fw.write(newline);
                }
            }
            fw.close();
        }catch(Exception e){
            System.out.println("File_IO Class: change_f_line has error!");
            System.out.println(e);
        }
    }
    
    void write_f(String path, String content, char mode){
        File file = new File(path);

        if(file.exists()){
            boolean perserve_content = true;
            switch(mode){
                case 'a':   //append mode
                case 'A':
                        perserve_content = true;
                        break;
                case 'o':   //overwrite mode
                case 'O':
                        perserve_content = false;
                        break;
            }
            try{
                //FileWriter fw = new FileWriter(file, perserve_content);
                FileOutputStream out = new FileOutputStream(file, perserve_content);
                OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
                fw.write(content);
                fw.close();
                // System.out.println("written to file: " + path);  //uncommon to be noisy
            }catch(Exception e){
                System.out.println("File_IO Class: write_f has error!");
                System.out.println(e);
            }
        }else{
            try{
                file.createNewFile();
                // FileWriter fw = new FileWriter(file);
                FileOutputStream out = new FileOutputStream(file);
                OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
                fw.write(content);
                fw.close();
                System.out.println("File created: " + path);
            }catch(Exception e){
                System.out.println("File_IO Class: write_f() has error!");
                System.out.println(e);
            }
        }
    }
}

class Termainal_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    Scanner in = new Scanner(System.in);

    boolean get_bool(String description){
        boolean output = false;
        boolean valid = false;
        do{
            System.out.print(description);
            String input = in.nextLine();
            switch(input){
                case "t":
                case "T":
                case "1":
                case "True":
                case "TRUE":
                case "true":
                    output = true;
                    valid = true;
                    break;
                case "f":
                case "F":
                case "0":
                case "False":
                case "FALSE":
                case "false":
                    output = false;
                    valid = true;
                    break;

            }
        }while(!valid);
        return output;
    }

    //the return dir may or may not has 'sep'
    String get_dir(){
        File file;
        String dir = "";
        boolean is_first = true;
        do{
            if(!is_first){
                System.out.println("Invalid dir. Try again!");
                print_line_sep();
            }
            is_first = false;
            System.out.print("Enter dir: ");
            dir = in.nextLine();
            //add 'sep' if missing
            if(dir.charAt(dir.length()-1) != sep){
                dir = dir + sep;
            }
            file = new File(dir);
        }while(!file.isDirectory());
        return dir;
    }
    
    void print_line_sep(){
        System.out.println("--------------------------------------");
    }
}
