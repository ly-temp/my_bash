#!/bin/bash
function dl_n_pre(){
	downloader_pausable_LY.sh "https://haodooclassic.net/PDB/;s" 0 "$i" > "$i".log
	cd download
	find . -type f -name '*.pdb' -exec sh -c 'iconv -f BIG-5 -t UTF8 -c "$1" -o "${1%.pdb}.txt"' sh {} \; -exec sh -c 'sed -i -e "s/︽/《/g" -e "s/︾/》/g" -e "s/﹁/「/g" -e "s/﹂/」/g" -e "s/︵/（/g" -e "s/︶/）/g" -e "s/｜/——/g" -e "s/︻/【/g" -e "s/︼/】/g" "${1%.pdb}.txt"' sh {} \; -exec rm {} \; -exec mkdir -p "../output" \; -exec sh -c 'mv -n "${1%.pdb}.txt" ../output/' sh {} \;
}
for i in *.dl;do
	folder="${i%.dl}-dl"
	mkdir -p "$folder"
	mv "$i" "$folder"
	cd "$folder"
	dl_n_pre &
	cd ../
done