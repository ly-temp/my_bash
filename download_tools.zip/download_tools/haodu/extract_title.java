import java.io.File;
import java.util.Scanner;

class extract_useful_url{
    static String out_suffix = ".txt";
    static String file_sep = System.getProperty("file.separator");
    static String allow_formats[] = {".txt"};
    static String title_markdown_open = "《";
    static String title_markdown_close = "》";
    static String null_strg = "\0";   //other than null ch
    static char null_ch = '\0';
    public static void main(String args[]){
        Termainal_IO terminal_io = new Termainal_IO();
        String dir = "";
        do{
            dir = terminal_io.get_dir();
        }while(!terminal_io.get_bool("Dir is: " + dir + "(T/F)? "));
        try {
            File dir_f = new File(dir);
            listFilesForFolder(dir_f);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    static public void listFilesForFolder(final File folder) {
        try{
            for (final File fileEntry : folder.listFiles()) {
                if (fileEntry.isDirectory()) {
                    listFilesForFolder(fileEntry);
                }else{
                    try{
                        //System.out.println(fileEntry.getName());
                        Scanner fr = new Scanner(fileEntry, "UTF-8");
                        String file_name = fileEntry.getName();
                        int dot_pos = file_name.lastIndexOf(".");
                        if(dot_pos != -1 && dot_pos != file_name.length() - 1){
                            //dot not found or at laste
                            for(String allow_format : allow_formats){
                                if(file_name.substring(dot_pos).equals(allow_format)){
                                    /**String line = fr.nextLine();*/
                                    String line = "";
                                    String title = "";
                                    String autor = "";
                                    String last_line = "";
                                    Boolean gotten = false;
                                    //customering!---------------------
                                    while(!gotten && fr.hasNext()){
                                        /**
                                        if(line.indexOf(title_markdown_open) == -1 && line.indexOf(title_markdown_close) == -1){
                                        line = fr.nextLine();
                                        }
                                        */
                                        line = fr.nextLine();
                                        if(last_line.equals("")){
                                            //first line --> first strg before null is book titile
                                            char ch = line.charAt(0);
                                            int i = 0;
                                            //while((ch = line.charAt(i)) != null_ch && i < line.length()){
                                            while(ch != null_ch && null_strg.indexOf(ch) == -1 && i < line.length()){                                            
                                                title += ch;
                                                i++;
                                                ch = line.charAt(i);
                                            }
                                        }
                                        if(line.equals("")){
                                            if(last_line.indexOf(title_markdown_open) != -1 && last_line.indexOf(title_markdown_close) != -1){
                                            //title = last_line.substring(last_line.lastIndexOf(title_markdown_open) + 1, line.lastIndexOf(title_markdown_close));
                                                autor = last_line.substring(last_line.lastIndexOf(title_markdown_close)+1);
                                            }
                                            gotten = true;//quit anyway if autor not found
                                        }
                                        last_line = line;
                                    }
                                    //filename format
                                    String new_filename = "";
                                    if(autor.equals("")){
                                        new_filename = title;
                                    }else{
                                        new_filename = title + " - " + autor;
                                    }
                                    //end of filename format

                                    //end of customerizing
                                    File new_f = new File(fileEntry.getParent(), new_filename + out_suffix);
                                    Long duplicate_counter = 1L;
                                    while(new_f.exists()){
                                        new_f = new File(fileEntry.getParent(), new_filename + "_" + Long.toString(duplicate_counter) + out_suffix);
                                        duplicate_counter++;
                                    }
                                    Boolean success = fileEntry.renameTo(new_f);
                                    System.out.print(success ? "[Success]" : "[Fail]");
                                    System.out.println(fileEntry.getAbsolutePath() + "\n    \\——>  " + new_f.getAbsolutePath());
                                }

                            }

                        }
                    }catch(Exception e){
                        System.out.println("[Fail]" + fileEntry.getAbsolutePath() + "\n");
                        System.out.println(e);
                    }

                    
                }
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
}

class Termainal_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    Scanner in = new Scanner(System.in);

    boolean get_bool(String description){
        boolean output = false;
        boolean valid = false;
        do{
            System.out.print(description);
            String input = in.nextLine();
            switch(input){
                case "t":
                case "T":
                case "1":
                case "True":
                case "TRUE":
                case "true":
                    output = true;
                    valid = true;
                    break;
                case "f":
                case "F":
                case "0":
                case "False":
                case "FALSE":
                case "false":
                    output = false;
                    valid = true;
                    break;

            }
        }while(!valid);
        return output;
    }

    //the return dir may or may not has 'sep'
    String get_dir(){
        File file;
        String dir = "";
        boolean is_first = true;
        do{
            if(!is_first){
                System.out.println("Invalid dir. Try again!");
                print_line_sep();
            }
            is_first = false;
            System.out.print("Enter dir: ");
            dir = in.nextLine();
            //add 'sep' if missing
            if(dir.charAt(dir.length()-1) != sep){
                dir = dir + sep;
            }
            file = new File(dir);
        }while(!file.isDirectory());
        return dir;
    }
    
    void print_line_sep(){
        System.out.println("--------------------------------------");
    }
}
