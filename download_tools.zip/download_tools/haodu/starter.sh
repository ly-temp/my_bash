#!/bin/bash
start_url="haodooclassic.net/PDB/"

#cp get_dl_strg.sh
#work for file explorer url only; output dl_strg.list
#$file_of_all_urls
function cut_standardize(){	#e.g. vertical/x
	awk -F '/' '{print $(NF-1) "/" $NF}'
}
function remove_special(){
	sed -E "s|/[A-Z,a-z]|/|g"
}
function cut_part(){
	cut_standardize | cut -d'.' -f1 | sort | uniq
}
function cut_fullpart(){
	cut_standardize | sort | uniq
}
function get_dl_strg(){
	>miss.list
	>epub.list

	grep ".epub$" "$1" | tee >(cut_fullpart > dl_strg.list) | cut_part > epub.list
	cut_part < "$1" > full.list
	while read -r full;do
		if ! grep -q "$full" "epub.list"
		then echo "$full" >> miss.list
		fi
	done < full.list
	while read -r miss;do
		grep -m1 -E "${miss}\." "$1" | cut_fullpart  >> dl_strg.list
	done < miss.list
	
#remove speical
	special_list=$(grep -E "/[A-Z,a-z]" dl_strg.list)
	while read -r special;do
		general_id=$(remove_special <<< "$special" | cut -d\/ -f2- | cut -d\. -f1)
		if grep "$general_id" dl_strg.list | grep -qv "$special"
		then
			perged_name=$(sed "s|/|\\\/|g" <<< "$special")
			sed -E "/$perged_name/d" -i "dl_strg.list"
		fi
	done <<< "$special_list"
}
#end

scan_f="scan.list"
>"$scan_f"
list=$(scan_html_LY.sh "https://$start_url")
while read -r url; do
	scan_html_LY.sh "$url" | grep "$start_url" | sed "s|.*$start_url||g" >> "$scan_f"
done <<< "$list"

list=$(grep -o "^." "$scan_f" | sort | uniq)
mkdir -p dl-list
cd dl-list
while read -r line;do
	grep "^$line" "../$scan_f" > "$line".dl
done <<< "$list"

for i in *.dl;do
	mkdir -p "${i%.*}-dl"
	cd "${i%.*}-dl"
	get_dl_strg "../$i"
	ls | grep -v "dl_strg.list" | xargs -I{} rm "{}"
	cd ../
done

mkdir -p OTHERS
mv *.dl OTHERS