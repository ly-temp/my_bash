#!/bin/bash

#cp get_dl_strg.sh
#work for file explorer url only; output dl_strg.list
#$file_of_all_urls
function cut_part(){
	awk -F '/' '{print $(NF-1) "/" $NF}' | cut -d'.' -f1 | sort | uniq
}
function cut_fullpart(){
	awk -F '/' '{print $(NF-1) "/" $NF}' | sort | uniq
}
function get_dl_strg(){
	>miss.list
	>epub.list
	grep ".epub$" "$1" | tee >(cut_fullpart > dl_strg.list) | cut_part > epub.list
	cat "$1" | cut_part > full.list
	while read -r full;do
		if ! grep -q "$full" "epub.list"
		then echo "$full" >> miss.list
		fi
	done < full.list
	while read -r miss;do
		grep -m1 -E "${miss}\." "$1" | cut_fullpart  >> dl_strg.list
	done < miss.list
}
#end

scan_f="scan.list"
>"$scan_f"
start_url="haodooclassic.net/PDB/"
list=$(scan_html_LY.sh "https://$start_url")
while read -r url; do
	scan_html_LY.sh "$url" | grep "$start_url" | sed "s|.*$start_url||g" >> "$scan_f"
done <<< "$list"

list=$(grep -o "^." "$scan_f" | sort | uniq)
mkdir -p dl-list
cd dl-list
while read -r line;do
	grep "^$line" "../$scan_f" > "$line".dl
done <<< "$list"

for i in *.dl;do
	mkdir -p "${i%.*}-dl"
	cd "${i%.*}-dl"
	get_dl_strg "../$i"
	ls | grep -v "dl_strg.list" | xargs -I{} rm "{}"
	cd ../
done

mkdir -p OTHERS
mv *.dl OTHERS