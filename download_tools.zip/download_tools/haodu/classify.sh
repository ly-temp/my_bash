#!/bin/bash
#$out.list
list=$(grep -o "^." "$1" | sort | uniq)
mkdir -p dl-list
cd dl-list
while read -r line;do
	grep "^$line" "../$1" > "$line".dl
done <<< "$list"