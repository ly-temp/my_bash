import java.io.File;
import java.io.FileInputStream;
import java.net.CacheRequest;
import java.util.Scanner;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;


class extract_useful_url{
    static String newline = System.getProperty("line.separator");
    public static void main(String args[]){
        Termainal_IO termainal_io = new Termainal_IO();
        File_IO file_io = new File_IO();

        Scanner in = new Scanner(System.in);
        File in_f;
        boolean valid = false;
        do{
            System.out.print("Enter file dir: ");
            in_f = new File(in.nextLine());
            valid = in_f.exists();
            if(!valid){
                System.out.println("Invalid file dir. Try again");
            }
        }while(!valid);
        System.out.print("Enter word contains: ");
        final String key_word = in.nextLine();
        System.out.println("Keyword is: " + key_word);
        System.out.print("Enter output file dir: ");
        String out_f_dir = "";
        File out_f;
        
        
        try{
            boolean create_file = false;
            do{
                create_file = false;
                out_f_dir = in.nextLine();
                out_f = new File(out_f_dir);
                if(out_f.exists()){
                    create_file = termainal_io.get_bool("File already existed. Overwrite?(T/F): ");
                    if(create_file){
                        file_io.write_f(out_f_dir, "", 'o');
                    }
                }else{
                    System.out.println("Output file created");
                    create_file = true;
                }
            }while(!create_file);
        }catch(Exception e){
            System.out.println(e);
        }

        try{
            Scanner in_f_sc = new Scanner(in_f, "UTF-8");
            while(in_f_sc.hasNext()){
                String line = in_f_sc.nextLine();
                if(line.indexOf(key_word) != -1){
                    //found link matched

                    //custom
                    String sep_line[] = line.split("'");
                    line = sep_line[1];
                    //end of custom

                    file_io.write_f(out_f_dir, line + newline, 'a');
                    System.out.println("Found: " + line);
                }
            }
            in_f_sc.close();
        }catch(Exception e){
            System.out.println(e);
        }
        
    }
}


class File_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    public static String eof_sign = "\n!!!EOF!!!";

    String read_file(String path, long line){    //line begin at 1
        String content = "";
        try{
            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            long i = 0;
            do{
                content = fr.nextLine();
                i++;
            }while(i < line && fr.hasNextLine());
            fr.close();
            if(i < line){
                content = eof_sign;
            }
        }catch(Exception e){
            System.out.println("File_IO Class: read_file has error!");
            System.out.println(e);
        }
        return content;
    }

    void change_f_line(String path, String content, int line){
        try{
            ArrayList<String> file_content = new ArrayList<String>();

            File file = new File(path);
            Scanner fr = new Scanner(file, "UTF-8");
            for(int i = 1; fr.hasNextLine(); i++){  //i: current line
                if(i == line){
                    //replace the line
                    fr.nextLine();
                    file_content.add(content);
                }else{
                    file_content.add(fr.nextLine());
                }
            }
            fr.close();
            //FileWriter fw = new FileWriter(file, false);
            FileOutputStream out = new FileOutputStream(file, false);
            OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
            for(int i = 0; i < file_content.size(); i++){
                fw.write(file_content.get(i));
                if(i != file_content.size() - 1){
                    fw.write(newline);
                }
            }
            fw.close();
        }catch(Exception e){
            System.out.println("File_IO Class: change_f_line has error!");
            System.out.println(e);
        }
    }
    
    void write_f(String path, String content, char mode){
        File file = new File(path);

        if(file.exists()){
            boolean perserve_content = true;
            switch(mode){
                case 'a':   //append mode
                case 'A':
                        perserve_content = true;
                        break;
                case 'o':   //overwrite mode
                case 'O':
                        perserve_content = false;
                        break;
            }
            try{
                //FileWriter fw = new FileWriter(file, perserve_content);
                FileOutputStream out = new FileOutputStream(file, perserve_content);
                OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
                fw.write(content);
                fw.close();
                // System.out.println("written to file: " + path);  //uncommon to be noisy
            }catch(Exception e){
                System.out.println("File_IO Class: write_f has error!");
                System.out.println(e);
            }
        }else{
            try{
                file.createNewFile();
                // FileWriter fw = new FileWriter(file);
                FileOutputStream out = new FileOutputStream(file);
                OutputStreamWriter fw = new OutputStreamWriter(out, "UTF-8");
                fw.write(content);
                fw.close();
                System.out.println("File created: " + path);
            }catch(Exception e){
                System.out.println("File_IO Class: write_f() has error!");
                System.out.println(e);
            }
        }
    }
}

class Termainal_IO{
    public static String newline = System.getProperty("line.separator");
    public static char sep = File.separatorChar;
    Scanner in = new Scanner(System.in);

    boolean get_bool(String description){
        boolean output = false;
        boolean valid = false;
        do{
            System.out.print(description);
            String input = in.nextLine();
            switch(input){
                case "t":
                case "T":
                case "1":
                case "True":
                case "TRUE":
                case "true":
                    output = true;
                    valid = true;
                    break;
                case "f":
                case "F":
                case "0":
                case "False":
                case "FALSE":
                case "false":
                    output = false;
                    valid = true;
                    break;

            }
        }while(!valid);
        return output;
    }

    //the return dir may or may not has 'sep'
    String get_dir(){
        File file;
        String dir = "";
        boolean is_first = true;
        do{
            if(!is_first){
                System.out.println("Invalid dir. Try again!");
                print_line_sep();
            }
            is_first = false;
            System.out.print("Enter dir: ");
            dir = in.nextLine();
            //add 'sep' if missing
            if(dir.charAt(dir.length()-1) != sep){
                dir = dir + sep;
            }
            file = new File(dir);
        }while(!file.isDirectory());
        return dir;
    }
    
    void print_line_sep(){
        System.out.println("--------------------------------------");
    }
}
